<?php 
require_once __DIR__ . '/../vendor/autoload.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deployments | System Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
    <style>
        :root {
            --primary-bg: #f8f9fa;
            --sidebar-bg: #212529;
            --card-bg: #ffffff;
            --accent-color: #0d6efd;
            --text-muted: #6c757d;
            --border-color: #dee2e6;
        }
        
        body {
            background-color: var(--primary-bg);
            font-family: 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            min-height: 100vh;
            display: flex;
        }
        
        .sidebar {
            background-color: var(--sidebar-bg);
            width: 250px;
            min-height: 100vh;
            color: white;
            transition: all 0.3s;
            position: fixed;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h3 {
            margin: 0;
            font-size: 1.3rem;
        }
        
        .sidebar-nav {
            padding: 0;
            list-style: none;
            margin-top: 1rem;
        }
        
        .sidebar-nav li {
            width: 100%;
        }
        
        .sidebar-nav a {
            display: block;
            padding: 0.8rem 1.5rem;
            color: rgba(255,255,255,0.75);
            text-decoration: none;
            transition: all 0.2s;
            display: flex;
            align-items: center;
        }
        
        .sidebar-nav a:hover {
            color: white;
            background-color: rgba(255,255,255,0.1);
        }
        
        .sidebar-nav a.active {
            color: white;
            background-color: var(--accent-color);
        }
        
        .sidebar-nav i {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            transition: all 0.3s;
            width: calc(100% - 250px);
        }
        
        .content-header {
            background: var(--card-bg);
            padding: 1.5rem 2rem;
            border-bottom: 1px solid var(--border-color);
        }
        
        .content {
            padding: 2rem;
        }
        
        .card {
            border-radius: 0.5rem;
            border: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        
        .btn-refresh {
            padding: 0.4rem 1rem;
            border-radius: 50px;
            background-color: var(--accent-color);
            color: white;
            border: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }

        .btn-refresh:hover {
            background-color: #0b5ed7;
        }

        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255,255,255,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .loading-spinner {
            width: 40px;
            height: 40px;
        }

        .badge-success {
            background-color: #d4edda;
            color: #155724;
        }

        .badge-danger {
            background-color: #f8d7da;
            color: #721c24; 
        }

        .badge-warning {
            background-color: #fff3cd;
            color: #856404;
        }

        .badge-info {
            background-color: #d1ecf1;
            color: #0c5460;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }
            .sidebar.active {
                margin-left: 0;
            }
            .main-content {
                width: 100%;
                margin-left: 0;
            }
            .main-content.active {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay">
        <div class="spinner-border text-primary loading-spinner" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3><i class="bi bi-speedometer me-2"></i>SePHP Monitor</h3>
        </div>
        <ul class="sidebar-nav">
            <li><a href="index.html"><i class="bi bi-house-door"></i> Dashboard</a></li>
            <li><a href="deployments-view.php" class="active"><i class="bi bi-rocket"></i> Deployments</a></li>
            <li><a href="github-events-view.php"><i class="bi bi-github"></i> GitHub Events</a></li>
            <li><a href="run-migrations-view.php"><i class="bi bi-database"></i> Migrations</a></li>
            <li><a href="webhook-view.php"><i class="bi bi-webhook"></i> Webhooks</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="content-header">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Deployments</h4>
                <button id="refreshButton" class="btn-refresh">
                    <i class="bi bi-arrow-clockwise"></i>
                    Refresh
                </button>
            </div>
        </div>
        
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <table id="deploymentsTable" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Repository</th>
                                <th>Branch</th>
                                <th>Commit</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Data will be populated by JavaScript -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
    <script>
        class DeploymentsUI {
            constructor() {
                this.table = null;
                this.setupEventListeners();
                this.initializeTable();
                this.loadDeployments();
            }

            setupEventListeners() {
                document.getElementById('refreshButton').addEventListener('click', () => {
                    this.loadDeployments();
                });
            }

            initializeTable() {
                this.table = $('#deploymentsTable').DataTable({
                    columns: [
                        { data: 'id' },
                        { data: 'repository' },
                        { data: 'branch' },
                        { 
                            data: 'commit_hash',
                            render: function(data) {
                                return data ? data.substring(0, 7) : 'N/A';
                            }
                        },
                        { 
                            data: 'status',
                            render: function(data) {
                                let badgeClass = '';
                                
                                if (data === 'success') badgeClass = 'badge-success';
                                else if (data === 'failed') badgeClass = 'badge-danger';
                                else if (data === 'pending') badgeClass = 'badge-warning';
                                else badgeClass = 'badge-info';
                                
                                return `<span class="badge ${badgeClass}">${data}</span>`;
                            }
                        },
                        { 
                            data: 'created_at',
                            render: function(data) {
                                const date = new Date(data);
                                return date.toLocaleString();
                            }
                        },
                        {
                            data: null,
                            render: function(data) {
                                return `
                                    <button class="btn btn-sm btn-outline-primary view-details" data-id="${data.id}">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                `;
                            }
                        }
                    ],
                    order: [[5, 'desc']], // Sort by date descending
                    responsive: true
                });

                // Setup detail view event
                $('#deploymentsTable').on('click', '.view-details', (e) => {
                    const id = $(e.currentTarget).data('id');
                    // Implementation for viewing deployment details would go here
                    alert(`View deployment details for ID: ${id}`);
                });
            }

            loadDeployments() {
                this.showLoading();
                
                fetch('deployments.php')
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            this.table.clear();
                            this.table.rows.add(data.data).draw();
                        } else {
                            console.error('Error loading deployments:', data.message);
                            alert('Failed to load deployments. Please try again.');
                        }
                        this.hideLoading();
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Failed to load deployments. Please try again.');
                        this.hideLoading();
                    });
            }

            showLoading() {
                document.getElementById('loadingOverlay').style.display = 'flex';
            }

            hideLoading() {
                document.getElementById('loadingOverlay').style.display = 'none';
            }
        }

        // Initialize dashboard when page loads
        document.addEventListener('DOMContentLoaded', () => {
            window.deploymentsUI = new DeploymentsUI();
        });
    </script>
</body>
</html>